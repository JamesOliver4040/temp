=== Fast Index ===
Contributors: cultdevops
Tags: Fast Index, Instant Index Google, Seo index, Google Index, Seo Problem
Requires at least: 5.1
Tested up to: 6.8
Stable tag: 2.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

If you have indexing and listing problem on google, you have to use this plugin. This plugin working with google API and fasted every plugin or seo.

== Description ==

If you have indexing problem on google, you have to use this plugin. This plugin working with google API and fasted every plugin or seo. When you publish new post, page or etc.. it will send your url to google.

FastIndex – 9 Results:

*Instant Indexing in Google when you Publish, Edit and Delete your post
*Fast Index can increase your visibility in google
*Working with Google Indexing API
*For real-time and instant indexing
*Increase your google indexes
*100% Legal, Safety and have high security
*Send your old posts, pages or etc.. to google
*Much more effective and faster than sitemaps
*You can exclude the categories


== Screenshots ==

1-screenshot-1.png
2-screenshot-2.png
2-screenshot-3.png
2-screenshot-4.png

== Changelog ==
= 2.1 =
* Download bug fixed

== Changelog ==
= 2.0 =
* Download bug fixed

== Changelog ==
= 1.10 =
* Added new post status
* Added licence key manager

= 1.9 =
* Bug fixed

= 1.8 =
* Added Manuel Cron Trigger

= 1.7 =
* Updated

= 1.6 =
* Php8 google API problem solved

= 1.5 =
* Php Tags bugs fixed

= 1.4 =
* Added "Exclude Categories"

= 1.3 =
* Fixed Bugs

= 1.2 =
* Added Language

= 1.1 =
* Added new language

= 1.0 =
* First Version All tested and working.


`<?php code(); ?>`